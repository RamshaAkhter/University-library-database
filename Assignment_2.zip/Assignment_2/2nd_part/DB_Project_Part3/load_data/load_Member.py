import mysql.connector
import pandas as pd

# Connect to MySQL
mydb = mysql.connector.connect(
    host='academicmysql.mysql.database.azure.com',
    database='mxs8337',
    user='mxs8337',
    password='Mehzad123456'
)

mycursor = mydb.cursor()

# Read data from Excel file
df = pd.read_excel('Member.xlsx')

# Iterate over each row in the DataFrame and insert into the MySQL database
for index, row in df.iterrows():
    member_id = row['MemberID']
    ssn = row['SSN']
    name = row['Name']
    campus_address = row['CampusAddress']
    home_address = row['HomeAddress']
    phone_number = row['PhoneNumber']
    membership_expiration_date = row['MembershipExpirationDate']
    is_professor = 1 if row['Is_professor'] == 'Yes' else 0
    membership_status = row['Membership_status']

    # Insert data into the MySQL database
    sql = "INSERT INTO member (MemberID, SSN, Name, CampusAddress, HomeAddress, PhoneNumber, MembershipExpirationDate, Is_professor, Membership_status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
    val = (member_id, ssn, name, campus_address, home_address, phone_number, membership_expiration_date, is_professor, membership_status)
    mycursor.execute(sql, val)

# Commit changes and close connection
mydb.commit()
mydb.close()

print("Data inserted successfully.")
