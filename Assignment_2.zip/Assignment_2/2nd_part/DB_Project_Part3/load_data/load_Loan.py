import mysql.connector
import pandas as pd

# Connect to MySQL
mydb = mysql.connector.connect(
    host='academicmysql.mysql.database.azure.com',
    database='mxs8337',
    user='mxs8337',
    password='Mehzad123456'
)

mycursor = mydb.cursor()

# Read data from Excel file
df = pd.read_excel('Loan.xlsx')

# Iterate over each row in the DataFrame and insert into the MySQL database
for index, row in df.iterrows():
    loan_id = row['LoanID']
    member_id = row['MemberID']
    volume_id = row['VolumeID']
    staff_id = row['StaffID']
    loan_date = row['LoanDate']
    due_date = row['DueDate']
    return_date = row['ReturnDate']

    # Insert data into the MySQL database
    sql = "INSERT INTO Loan (LoanID, MemberID, VolumeID, StaffID, LoanDate, DueDate, ReturnDate) VALUES (%s, %s, %s, %s, %s, %s, %s)"
    val = (loan_id, member_id, volume_id, staff_id, loan_date, due_date, return_date)
    mycursor.execute(sql, val)

# Commit changes and close connection
mydb.commit()
mydb.close()

print("Data inserted successfully.")
