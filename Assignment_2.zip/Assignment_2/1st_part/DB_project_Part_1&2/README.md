
Course: CSE-5330-002-DATABASE SYSTEMS


Title: Project 2

Submitted by: 1) Mehzad Hossain Setu – 1002138330
	      2) RAMSHA AKHTER - 1002163645


Description: This zip file is submission of Project 2 (Part 1 & 2).

Contents:
table.txt: This file contains all the create table queries as per the project requirements.

output_p2.txt: Captured results of the create table queries are stored in this file.

EER_Diagram.drawio.png: Image of the Entity-Relationship Diagram (EER Diagram) created based on the project requirements.

EERtoSchema.png: Image representing the process of converting the EER Diagram to a Database Schema.

The "Project 2 DB.pdf" contains detailed instructions for designing and implementing.

