import mysql.connector
import pandas as pd

# Connect to MySQL
mydb = mysql.connector.connect(
    host='academicmysql.mysql.database.azure.com',
    database='mxs8337',
    user='mxs8337',
    password='Mehzad123456'
)

mycursor = mydb.cursor()

# Read data from Excel file
df = pd.read_excel('Book.xlsx')

# Iterate over each row in the DataFrame and insert into the MySQL database
for index, row in df.iterrows():
    isbn = row['ISBN']
    title = row['Title']
    author = row['Author']
    subject_area = row['SubjectArea']
    edition = row['Edition']
    binding = row['Binding']
    language = row['Language']
    can_loan = 1 if row['Can_loan'] == 'Yes' else 0

    # Insert data into the MySQL database
    sql = "INSERT INTO book (ISBN, Title, Author, SubjectArea, Edition, Binding, Language, Can_loan) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
    val = (isbn, title, author, subject_area, edition, binding, language, can_loan)
    mycursor.execute(sql, val)

# Commit changes and close connection
mydb.commit()
mydb.close()

print("Data inserted successfully.")
