import mysql.connector
import pandas as pd

# Connect to MySQL
mydb = mysql.connector.connect(
    host='academicmysql.mysql.database.azure.com',
    database='mxs8337',
    user='mxs8337',
    password='Mehzad123456'
)

mycursor = mydb.cursor()

# Read data from Excel file
df = pd.read_excel('WantedBook.xlsx')

# Iterate over each row in the DataFrame and insert into the MySQL database
for index, row in df.iterrows():
    wanted_book_id = row['WantedBookID']
    isbn = row['ISBN']
    title = row['Title']
    author = row['Author']
    reason_for_interest = row['ReasonForInterest']

    # Insert data into the MySQL database
    sql = "INSERT INTO WantedBook (WantedBookID, ISBN, Title, Author, ReasonForInterest) VALUES (%s, %s, %s, %s, %s)"
    val = (wanted_book_id, isbn, title, author, reason_for_interest)
    mycursor.execute(sql, val)

# Commit changes and close connection
mydb.commit()
mydb.close()

print("Data inserted successfully.")
