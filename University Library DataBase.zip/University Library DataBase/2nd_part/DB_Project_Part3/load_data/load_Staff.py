import mysql.connector
import pandas as pd

# Connect to MySQL
mydb = mysql.connector.connect(
    host='academicmysql.mysql.database.azure.com',
    database='mxs8337',
    user='mxs8337',
    password='Mehzad123456'
)

mycursor = mydb.cursor()

# Read data from Excel file
df = pd.read_excel('Staff.xlsx')

# Iterate over each row in the DataFrame and insert into the MySQL database
for index, row in df.iterrows():
    staff_id = row['StaffID']
    name = row['Name']
    role = row['Role']

    # Insert data into the MySQL database
    sql = "INSERT INTO Staff (StaffID, Name, Role) VALUES (%s, %s, %s)"
    val = (staff_id, name, role)
    mycursor.execute(sql, val)

# Commit changes and close connection
mydb.commit()
mydb.close()

print("Data inserted successfully.")
