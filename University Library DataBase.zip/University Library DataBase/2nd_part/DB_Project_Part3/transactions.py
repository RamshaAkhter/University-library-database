import mysql.connector
from datetime import datetime, timedelta


# Function to add information about a new member
def add_new_member(cursor, connection):
    print("\nEnter Details of New Member.")
    member_id = input("Enter Member ID: ")
    ssn = input("Enter SSN: ")
    name = input("Enter Name: ")
    campus_address = input("Enter Campus Address: ")
    home_address = input("Enter Home Address: ")
    phone_number = input("Enter Phone Number: ")
    expiration_date = input("Enter Membership Expiration Date (YYYY-MM-DD): ")
    is_professor = input("Is Professor (1 for True, 0 for False): ")
    membership_status = input("Enter Membership Status: ")

    add_member_query = '''INSERT INTO Member (MemberID, SSN, Name, CampusAddress, HomeAddress, PhoneNumber, MembershipExpirationDate, Is_professor, Membership_status)
                          VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)'''
    member_data = (
    member_id, ssn, name, campus_address, home_address, phone_number, expiration_date, is_professor, membership_status)

    cursor.execute(add_member_query, member_data)
    connection.commit()
    print("New member added successfully!")

# Function to add information about a new Book
def add_new_book(cursor, connection):
    print("\nEnter Details of New Book.")
    isbn = input("Enter ISBN: ")
    title = input("Enter Title: ")
    author = input("Enter Author: ")
    subject_area = input("Enter Subject Area: ")
    edition = input("Enter Edition: ")
    binding = input("Enter Binding: ")
    language = input("Enter Language: ")
    can_loan = input("Can be loaned? (1 for True, 0 for False): ")
    total_copy = int(input("Enter Total Copies: "))
    available_copy = int(input("Enter Available Copies: "))
    description = input("Enter Description: ")
    status = input("Enter Status (Available/ On loan): ")

    # Insert into Book table
    add_book_query = '''INSERT INTO Book (ISBN, Title, Author, SubjectArea, Edition, Binding, Language, Can_loan)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)'''
    book_data = (isbn, title, author, subject_area, edition, binding, language, can_loan)
    cursor.execute(add_book_query, book_data)

    # Insert into Catalog table
    add_catalog_query = '''INSERT INTO Catalog (ISBN, Total_copy, Available_copy, Description)
                           VALUES (%s, %s, %s, %s)'''
    catalog_data = (isbn, total_copy, available_copy, description)
    cursor.execute(add_catalog_query, catalog_data)

    # Insert into Volume table
    #volume_data = (None, isbn, 'Available')  # VolumeID is auto-generated
    #add_volume_query = '''INSERT INTO Volume (VolumeID, ISBN, Status) VALUES (NULL, %s, %s)'''
    add_volume_query = '''INSERT INTO Volume (ISBN, Status) VALUES (%s, %s)'''
    volume_data = (isbn, status)

    #volume_data = (None, isbn, status)
    cursor.execute(add_volume_query, volume_data)

    connection.commit()
    print("New book added successfully!")


# Function to add information about a new Borrow (loan)
def add_new_borrow(cursor, connection):
    print("\nEnter Details to Borrow a Book.")
    while True:
        member_id = input("Enter Member ID: ")
        # Check if the member ID exists in the database
        check_member_query = "SELECT * FROM Member WHERE MemberID = %s"
        cursor.execute(check_member_query, (member_id,))
        member = cursor.fetchone()
        if member:
            if member[8] == 'Inactive':
                print("Your membership is inactive. You cannot borrow a book.")
                return
            break  # Valid member ID found, exit loop
        else:
            print("Invalid Member ID. Please try again.")

    isbn = input("Enter ISBN of the book to borrow: ")

    # Check if the book is available for loan
    check_book_query = '''SELECT Book.Can_loan 
                          FROM Book 
                          WHERE Book.ISBN = %s'''
    cursor.execute(check_book_query, (isbn,))
    can_loan = cursor.fetchone()

    if can_loan:
        if can_loan[0] == 0:
            print("This book cannot be loaned.")
            return
        elif can_loan[0] == 1:
            # Check if the book is available (status is 'Available') in the Volume table
            check_volume_query = '''SELECT Volume.Status 
                                    FROM Volume
                                    WHERE Volume.ISBN = %s'''
            cursor.execute(check_volume_query, (isbn,))
            volume_status = cursor.fetchone()

            if volume_status:
                if volume_status[0] != 'Available':
                    print("This book is not available for loan.")
                    return
                else:
                    # Proceed with borrowing process
                    loan_id = input("Enter Loan ID: ")
                    staff_id = input("Enter Staff ID: ")
                    loan_date = datetime.now().strftime('%Y-%m-%d')
                    due_date = (datetime.now() + timedelta(days=14)).strftime('%Y-%m-%d')  # Due in 14 days

                    # Insert into Loan table
                    add_borrow_query = '''INSERT INTO Loan (LoanID, MemberID, VolumeID, StaffID, LoanDate, DueDate)
                                          VALUES (%s, %s, (SELECT VolumeID FROM Volume WHERE ISBN = %s), %s, %s, %s)'''
                    borrow_data = (loan_id, member_id, isbn, staff_id, loan_date, due_date)
                    cursor.execute(add_borrow_query, borrow_data)

                    # Update available_copy in Catalog table
                    update_catalog_query = '''UPDATE Catalog SET Available_copy = Available_copy - 1 WHERE ISBN = %s'''
                    cursor.execute(update_catalog_query, (isbn,))

                    connection.commit()
                    print("Book borrowed successfully.")
                    return
            else:
                print("Invalid ISBN.")
                return
    else:
        print("Invalid ISBN.")
        return

    loan_id = input("Enter Loan ID: ")
    staff_id = input("Enter Staff ID: ")
    loan_date = datetime.now().strftime('%Y-%m-%d')
    due_date = (datetime.now() + timedelta(days=14)).strftime('%Y-%m-%d')  # Due in 14 days

    # Insert into Loan table
    add_borrow_query = '''INSERT INTO Loan (LoanID, MemberID, VolumeID, StaffID, LoanDate, DueDate)
                          VALUES (%s, %s, (SELECT VolumeID FROM Volume WHERE ISBN = %s), %s, %s, %s)'''
    borrow_data = (loan_id, member_id, isbn, staff_id, loan_date, due_date)
    cursor.execute(add_borrow_query, borrow_data)

    # Update available_copy in Catalog table
    update_catalog_query = '''UPDATE Catalog SET Available_copy = Available_copy - 1 WHERE ISBN = %s'''
    cursor.execute(update_catalog_query, (isbn,))

    connection.commit()
    print("Book borrowed successfully!")



# Function to handle the return of a book
def handle_book_return(cursor, connection):
    loan_id = input("Enter Loan ID: ")
    return_date = datetime.now().strftime('%Y-%m-%d')

    # Check if ReturnDate is empty for the given loan ID
    check_return_date_query = '''SELECT ReturnDate FROM Loan WHERE LoanID = %s'''
    cursor.execute(check_return_date_query, (loan_id,))
    return_date_result = cursor.fetchone()

    if return_date_result[0] is None:
        # Update ReturnDate in Loan table
        update_return_query = '''UPDATE Loan SET ReturnDate = %s WHERE LoanID = %s'''
        return_data = (return_date, loan_id)
        cursor.execute(update_return_query, return_data)

        # Fetch book details for the receipt
        cursor.execute('''SELECT Book.Title, Loan.LoanDate, Loan.ReturnDate, Volume.ISBN
                          FROM Loan
                          INNER JOIN Volume ON Loan.VolumeID = Volume.VolumeID
                          INNER JOIN Book ON Volume.ISBN = Book.ISBN
                          WHERE Loan.LoanID = %s''',
                       (loan_id,))
        book_info = cursor.fetchone()
        if book_info:
            print("Return Receipt:")
            print("Book Title:", book_info[0])
            print("Borrowed Date:", book_info[1])
            print("Return Date:", book_info[2])
            print("Thank you for returning the book!")

            # Update Catalog table to increment available copy
            isbn = book_info[3]
            update_catalog_query = '''UPDATE Catalog SET Available_copy = Available_copy + 1 WHERE ISBN = %s'''
            cursor.execute(update_catalog_query, (isbn,))
        else:
            print("Invalid Loan ID!")
    else:
        print("This book has already been returned.")

    connection.commit()


# Function to renew the membership
def renew_membership(cursor, connection):
    member_id = input("Enter Member ID to renew membership: ")
    new_expiration_date = input("Enter new Membership Expiration Date (YYYY-MM-DD): ")

    renew_membership_query = '''UPDATE Member
                                SET MembershipExpirationDate = %s
                                WHERE MemberID = %s'''
    renew_data = (new_expiration_date, member_id)

    cursor.execute(renew_membership_query, renew_data)
    connection.commit()
    print("Membership renewed successfully!")


# Main function to interact with the user and perform transactions
def main():
    # Connect to the database
    connection = mysql.connector.connect(
        host='academicmysql.mysql.database.azure.com',
        database='mxs8337',
        user='mxs8337',
        password='Mehzad123456'
    )
    cursor = connection.cursor()

    while True:
        print("\nMenu:")
        print("1. Add new member")
        print("2. Add new book")
        print("3. Borrow a book")
        print("4. Return a book")
        print("5. Renew membership")
        print("6. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            add_new_member(cursor, connection)
        elif choice == '2':
            add_new_book(cursor, connection)
        elif choice == '3':
            add_new_borrow(cursor, connection)
        elif choice == '4':
            handle_book_return(cursor, connection)
        elif choice == '5':
            renew_membership(cursor, connection)
        elif choice == '6':
            break
        else:
            print("Invalid choice! Please enter a number from 1 to 6.")

    # Close connection
    cursor.close()
    connection.close()


if __name__ == "__main__":
    main()
