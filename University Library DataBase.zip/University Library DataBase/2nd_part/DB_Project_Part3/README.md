
Course: CSE-5330-002-DATABASE SYSTEMS


Title: Project 2

Submitted by: 1) Mehzad Hossain Setu – 1002138330
	      2) RAMSHA AKHTER - 1002163645


Description: This zip file is submission of Project 2 (Part 3).

Contents:
Datasets : Contains Excel files for various datasets such as Book, Catalog, Loan, Member, NonLendableBook, Staff, Volume, and WantedBook.

load_data : Contains Python scripts for loading data into the corresponding database tables. Each script is named according to the dataset it loads.

query.txt: Contains SQL queries to retrieve data from the database.(Q2,Q3,Q5)

spool_Q2&Q3.txt: Contains the results of queries Q2 and Q3.

transactions.py: Python script to execute various transactions such as adding a new member, adding a new book, borrowing a book, returning a book, renewing membership, etc.

recording.txt: Captures a sample transaction session with the Python script.

spool_Q5.txt: Contains the results of queries Q5 and show notification results. 

transaction_error.txt: Contains additional transaction logs. Some corner cases. 

Project_3_Report.pdf: This report provides an overview of the LMS, its features, implementation details.




